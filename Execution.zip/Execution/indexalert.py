import numpy as np 
import datetime
from nested_lookup import nested_lookup
import json
import requests
url = "https://web-api-pepper.horizon.tv/oesp/v2/NL/nld/web/channels"
res = requests.get(url)
print(res.status_code)
now = datetime.datetime.now()
data=res.json()
class NullValError(Exception):
    """Raised when there are Empty Values"""
    pass
#### TRY Block To Execute When The URL Is Reachable################
try:
    assert res.status_code == 200
    dict1={}
    dict1['timestamp']= now.strftime("%Y-%m-%dT%H:%M:%S")
    dict1['totalResults']=data['totalResults']
    #dict1['totalResults']=""
    dict1['streamUrl']=len(nested_lookup('streamingUrl', data))
    #dict1["streamUrl"]=""
    print(dict1)
    if dict1['streamUrl']=="" or dict1['totalResults']=="":
        raise NullValError(Exception)

#### Connecting To Elastic Search###########    
    url_es='http://localhost:9200/esi/_doc' 
    header={'Content-Type': 'application/json'}
    response=requests.post(url_es, headers=header, data=json.dumps(dict1))
    print(response.text)
#####Executes When the response from URL is Not Fetched ####    
except AssertionError: 
    print("URL is not reachable")
#### To Be Executed When Total Results/ StreamUrl Field Has Null Values"     
except NullValError:
    print("*********Null Values for TotalResults/StreamUrl**********")

